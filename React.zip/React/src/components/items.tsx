
export const items=[
     {id:1, name:'Shirt',category:'shirts',src:'Picters/Shirt1.jpg',price:'17$'},
     {id:2, name:'shirt',category:'shirts',src:'Picters/shirt2.jpg',price:'17$'},
     {id:3, name:'shirt',category:'shirts',src:'Picters/shirt3.jpg',price:'19$'},
     {id:4, name:'shirt',category:'shirts',src:'Picters/shirt4.jpg',price:'18$'},
     {id:5, name:'abaya',category:'abaya',src:'Picters/abaya2.jpg',price:'100$'},
     {id:6, name:'abaya',category:'abaya',src:'Picters/abaya1.jpg',price:'98$'},
     {id:7, name:'abaya',category:'abaya',src:'Picters/abaya3.jpg',price:'98$'},
     {id:8, name:'abaya',category:'abaya',src:'Picters/abaya4.jpg',price:'98$'},
     {id:9, name:'abaya',category:'abaya',src:'Picters/abaya5.jpg',price:'98$'},
     {id:10, name:'abaya',category:'abaya',src:'Picters/abaya6.jpg',price:'98$'},
     {id:11, name:'dress',category:'dresses',src:'Picters/dresse1.jpg',price:'100$'},
     {id:12, name:'dress',category:'dresses',src:'Picters/dresse2.jpg',price:'100$'},
 
     
 ];



