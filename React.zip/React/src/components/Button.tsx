
interface Props {
     children: string;
     color?: 'primary'|'dark';
     onClick: ()=> void;
}

const Button = ({children,color ='dark', onClick}:Props) => {
  return (
    <button className={"btn btn-dark m-1"}  onClick={onClick}> {children}</button>
  );
}


export default Button;