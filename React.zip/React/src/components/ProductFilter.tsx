import { useEffect, useState } from "react";
import React from 'react'
import { items } from "./items";
import '../App.css';






const ProductFilter = () => {
   const [item,setItem]=useState(items);
   console.log(items)  ;

   const filterItems =(catItem:string) =>{
     const updateItems=items.filter((curItem)=>{
          return curItem.category === catItem

     });
     setItem(updateItems);
   }
  return (
    <div  className="container mt-5">
     
     <h1 className="header">Our Proudct</h1>
      <div className="filtterButton">
      <button className="active"   onClick={()=>setItem(items)}> All </button>
      <button  onClick={()=>filterItems("dresses")}> Dresses </button>
      <button  onClick={()=>filterItems("abaya")}> Abaya </button>
      <button  onClick={()=>filterItems("shirts")}> Shirts </button>
      </div>
      <div className="filterable_card">
          {item.map((val)=>
          <div className="card">
                    
          <img src= {val.src} alt={val.category}/>
          <div className="card_body">
          <h3 >{val.name}</h3>
          <p>{val.category}</p>
          <p>{val.price}</p>
           </div>
         </div>
          

          )}

      </div>
     </div>
    
  );
}

export default ProductFilter;



